from core import headers as kosto
from core import logo
from core import extra
from core import login
try:import os,requests,time,sys,random
except:os.system(extra.req())
from time import gmtime, strftime
total_earn = 0
def __cls__():
    os.system('clear')
    print(logo.get())
def color():
    colors =[
    '\033[1;32m','\033[1;31m',
    '\033[1;34m','\033[1;35m',
    '\033[0m','\033[0;34m',
    '\033[1;36m','\033[39m',
    ]
    return random.choice(colors)
def process(info):
    xyz = requests.Session()
    token = info['token']
    name = info['name']
    headers = kosto.get(token=token)
    url = "https://api-backend.yescoin.gold/user/offline"
    req = xyz.post(url,headers=headers).text
    url = 'https://api-backend.yescoin.gold/game/collectCoin'
    json_data = int(random.randint(108, 209))
    req = xyz.post(url,headers=headers,json=json_data).json()
    total_earn = str(json_data)
    print(f'\033[0m[{strftime("%H:%M:%S", gmtime())}] {color()}{name} Balance: {req["data"]["currentAmount"]} Earn: {req["data"]["collectAmount"]} ')

def __menu__():
    __cls__()
    links = open('core/login_links.txt','r').read()
    acc = str(len(links.splitlines()))
    axd,tok = "Alive",[]
    for err_url in links.splitlines():
        if len(err_url) < 1:
            exit("No links in `/core/login_links.txt` ")
        try:
           info = login.de(err_url)
           token = info['token']
           if len(token) < 10:
              axd = "\033[1;31mWrong"
           tok.append(info)
        except Exceptions as e:pass
    print(f'Total Accaunt :\033[1;32m {acc}\033[0m')
    print(f'Access Token  :\033[1;32m {axd}\033[0m')
    print(logo.__br__())
    input('Press enter to start ')
    __cls__()
    print(f'Total Accaunt :\033[1;32m {acc}\033[0m')
    print(f'Access Token  :\033[1;32m {axd}\033[0m')
    print(logo.__br__())
    unlimited = 9999999999999999999999999999999999
    for i in range(unlimited):
       for info in tok:
          try:
            process(info)
          except Exception as e:
            pass
if __name__ == '__main__':
    __menu__()
